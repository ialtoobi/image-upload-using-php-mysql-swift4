<?php
	
	include 'include/connect.php';
	
  	//Get Param Data
  	$name = $_POST["name"];
	$age = $_POST["age"];
	
	$xName = mysqli_real_escape_string($conn, $name);
	$xAge = mysqli_real_escape_string($conn, $age);
	
	
	//Results Array
	$result = array();
	
  	//Image setup
	$uploads_dir = 'img';
	$tmp_name = $_FILES["image"]["tmp_name"];
	$image_name = basename($_FILES["image"]["name"]);
	$supported_image = array('gif','jpg','jpeg','png');
	
	$ext = strtolower(pathinfo($image_name, PATHINFO_EXTENSION)); 
	

	if(empty($xName) || empty($xAge)|| empty($image_name))
	{
		
		// Send some dummy result back to the iOS app
		$result["message"] = "Sorry, there was an error uploading your file.";
		$result["status"] = "0";
		$result["post"] = $_POST;
		$result["files"] = $_FILES;


	}
	
	if (! in_array($ext, $supported_image)) 
	{
	   		
	  	// Send some dummy result back to the iOS app
		$result["message"] = "Sorry, Image extension is not Allowed!";
		$result["status"] = "0";
		$result["post"] = $_POST;
		$result["files"] = $_FILES;
		    
	} 
	else
	 {
		 
		 $query ="INSERT INTO images (name, age, image) VALUES ('$xName', '$xAge','$image_name')";
		
		if (mysqli_query($conn, $query)) {
			
			move_uploaded_file($tmp_name,"$uploads_dir/$image_name");
			
			// Send some dummy result back to the iOS app
			$result["message"] = "Data has been uploaded successfully.";
			$result["status"] = "1";
			$result["post"] = $_POST;
			$result["files"] = $_FILES;
				
		}	   
	 }

	echo json_encode($result);
		
?>


